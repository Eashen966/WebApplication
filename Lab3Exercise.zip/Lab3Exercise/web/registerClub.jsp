<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>Registration Page</title>
</head>
<body style="font-family: Arial, sans-serif; margin: 0; padding: 0;">

    <%-- Include Directive for Header --%>
    <%@ include file="header.jsp" %>

    <div style="width: 50%; margin: auto;">
        <h2>Register for a Club</h2>
        
        <form action="processRegistration.jsp" method="POST">
            <p>
                <label>Student Name:</label><br>
                <input type="text" name="studentName" size="30" required>
            </p>
            <p>
                <label>Matric Number:</label><br>
                <input type="text" name="matricNumber" size="30" required>
            </p>
            <p>
                <label>Selected Club:</label><br>
                <select name="selectedClub" required>
                    <option value="">-- Please Select --</option>
                    <option value="Computer Science Club">Computer Science Club</option>
                    <option value="Mathematics Club">Mathematics Club</option>
                    <option value="COMTECH">COMTECH</option>
                    <option value="HIMMAT">HIMMAT</option>
                </select>
            </p>
            <input type="submit" value="Submit Registration" style="padding: 5px 15px; background-color: blue ;color: white; border: none; cursor: pointer;">
        </form>
    </div>

    <%-- Include Directive for Footer --%>
    <%@ include file="footer.jsp" %>

</body>
</html>