<%-- 
    Document   : footer
    Created on : Apr 14, 2026, 12:00:37 PM
    Author     : eashenraj
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <br><br>
        <div style="background-color: #f1f1f1; padding: 15px; text-align: center; font-family: Arial, sans-serif; border-top: 2px solid #ccc;">
            <p style="margin: 0; font-size: 0.9em; color: #555;">&copy; 2026 FSKM, UMT. All rights reserved.</p>
        </div>
    </body>
</html>
