<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>Fee Calculator</title>
</head>
<body style="font-family: Arial, sans-serif; margin: 0; padding: 0;">

    <%@ include file="header.jsp" %>

    <div style="width: 50%; margin: auto;">
        <h2>Membership Fee Calculator</h2>
        
        <form action="feeCalculator.jsp" method="POST">
            <p>
                <label>Number of activities joined:</label>
                <input type="number" name="numActivities" min="1" required>
            </p>
            <input type="submit" value="Calculate Fee">
        </form>

        <br>
        
        <%
            String activitiesStr = request.getParameter("numActivities");
            
            // Only perform calculation if the form has been submitted
            if (activitiesStr != null && !activitiesStr.isEmpty()) {
                int numOfActivities = Integer.parseInt(activitiesStr);
                
                // Mathematical Logic: Each activity costs RM10
                double totalFee = numOfActivities * 10.00;
                
                // Format output to 2 decimal places
                String formattedFee = String.format("%.2f", totalFee);
        %>
                <div style="background-color: #e6f2ff; padding: 15px; border: 1px solid #b3d9ff;">
                    <h3 style="margin: 0;">Total Fee: RM <%= formattedFee %></h3>
                    <p style="margin: 5px 0 0 0;">(Calculation based on <%= numOfActivities %> activities at RM 10.00 each)</p>
                </div>
        <%
            }
        %>
    </div>

    <%@ include file="footer.jsp" %>

</body>
</html>