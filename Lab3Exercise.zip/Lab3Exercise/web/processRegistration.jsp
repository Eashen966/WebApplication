<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.util.ArrayList"%>
<!DOCTYPE html>
<html>
<head>
    <title>Registration Success</title>
</head>
<body style="font-family: Arial, sans-serif; margin: 0; padding: 0;">

    <%@ include file="header.jsp" %>

    <div style="width: 50%; margin: auto;">
        <h2 style="color: green;">Registration Successful!</h2>
        
        <%
            // 1. Retrieve parameters from the form
            String name = request.getParameter("studentName");
            String matric = request.getParameter("matricNumber");
            String club = request.getParameter("selectedClub");

            // 2. Retrieve the global member list from the application scope
            ArrayList<String[]> globalMemberList = (ArrayList<String[]>) application.getAttribute("clubMembersDB");
            
            // 3. If the list doesn't exist yet, create it
            if (globalMemberList == null) {
                globalMemberList = new ArrayList<String[]>();
            }
            
            // 4. Add the new user's details as a String array [Name, Matric, Club]
            globalMemberList.add(new String[]{name, matric, club});
            
            // 5. Save the updated list back into the application scope
            application.setAttribute("clubMembersDB", globalMemberList);
        %>
        
        <fieldset>
            <legend><strong>Student Details Saved:</strong></legend>
            <p><strong>Name:</strong> <%= name %></p>
            <p><strong>Matric Number:</strong> <%= matric %></p>
            <p><strong>Club Joined:</strong> <%= club %></p>
        </fieldset>
        
        <br>
        <a href="memberDirectory.jsp">View Member Directory</a>
    </div>

    <%@ include file="footer.jsp" %>

</body>
</html>