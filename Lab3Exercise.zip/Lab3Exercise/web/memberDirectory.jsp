<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.util.ArrayList"%>
<!DOCTYPE html>
<html>
<head>
    <title>Club Member Directory</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }
        th {
            background-color: #004d99;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body style="font-family: Arial, sans-serif; margin: 0; padding: 0;">

    <%@ include file="header.jsp" %>

    <div style="width: 60%; margin: auto;">
        <h2>Committee & Member Directory</h2>
        
        <%
            // 1. Try to get the global list from application scope
            ArrayList<String[]> directoryList = (ArrayList<String[]>) application.getAttribute("clubMembersDB");
            
            // 2. If it's null, initialize it and add the default committee members
            if (directoryList == null) {
                directoryList = new ArrayList<String[]>();
                directoryList.add(new String[]{"Kishori Kumar", "-", "Committee"});
                
                // Save it to application scope so it's there next time
                application.setAttribute("clubMembersDB", directoryList);
            }
        %>

        <table>
            <tr>
                <th>No.</th>
                <th>Member Name</th>
                <th>Matric Number</th>
                <th>Club / Role</th>
            </tr>
            <%
                // 3. Dynamically display the names in an HTML table
                for (int i = 0; i < directoryList.size(); i++) {
                    String[] memberData = directoryList.get(i);
            %>
                <tr>
                    <td><%= (i + 1) %></td>
                    <td><%= memberData[0] %></td> <td><%= memberData[1] %></td> <td><%= memberData[2] %></td> </tr>
            <%
                }
            %>
        </table>
    </div>

    <%@ include file="footer.jsp" %>

</body>
</html>