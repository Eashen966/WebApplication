<%-- 
    Document   : header
    Created on : Apr 14, 2026, 12:00:20 PM
    Author     : eashenraj
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <div style="background-color: blue; color: white; padding: 20px; text-align: center; font-family: Arial, sans-serif;">
            <h1 style="margin: 0;">UMT Student Club Recruitment</h1>
            <p>Faculty of Computer Science and Mathematics</p>
            <nav style="margin-top: 10px;">
                <a href="registerClub.jsp" style="color: white; text-decoration: none; margin: 0 15px; font-weight: bold;">Registration</a> 
                <a href="feeCalculator.jsp" style="color: white; text-decoration: none; margin: 0 15px; font-weight: bold;">Fee Calculator</a> 
                <a href="memberDirectory.jsp" style="color: white; text-decoration: none; margin: 0 15px; font-weight: bold;">Club Member Directory</a>
            </nav>
        </div>
        <br>
    </body>
</html>
