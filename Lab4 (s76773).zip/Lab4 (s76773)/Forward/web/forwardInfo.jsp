<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Forward Information</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f7f6;
            margin: 0;
            padding: 20px;
        }
        .container {
            width: 100%;
            max-width: 900px;
            margin: 0 auto;
        }
        h1 {
            font-size: 1.5rem;
            color: #333;
            margin-bottom: 20px;
            border-left: 5px solid #6f42c1;
            padding-left: 10px;
        }
        .card {
            background: #ffffff;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            max-width: 500px;
            margin-left: auto;
            margin-right: auto;
        }
        .card-title {
            color: #6f42c1;
            font-size: 1.8rem;
            font-weight: 600;
            margin-top: 0;
            margin-bottom: 25px;
        }
        .data-row {
            margin-bottom: 15px;
            font-size: 1.1rem;
            color: #333;
        }
        .label {
            font-weight: bold;
            color: #555;
            margin-right: 5px;
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>Using jsp:forward to display user info</h1>

        <div class="card">
            <h2 class="card-title">Forwarded Info</h2>

            <%-- 3. Retrieve the forwarded parameters using the correct keys --%>
            <%
                String name = request.getParameter("uname");
                String email = request.getParameter("email");
                String nationality = request.getParameter("nationality");
                String background = request.getParameter("background");
            %>

            <%-- 4. Display the data using JSP Expressions --%>
            <div class="data-row">
                <span class="label">Name:</span> <%= (name != null) ? name : "" %>
            </div>
            <div class="data-row">
                <span class="label">Email:</span> <%= (email != null) ? email : "" %>
            </div>
            <div class="data-row">
                <span class="label">Nationality:</span> <%= (nationality != null) ? nationality : "" %>
            </div>
            <div class="data-row">
                <span class="label">Background:</span> <%= (background != null) ? background : "" %>
            </div>
        </div>
    </div>

</body>
</html>