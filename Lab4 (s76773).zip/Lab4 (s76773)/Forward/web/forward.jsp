<%-- 
    Document   : forward
    Created on : 21 Apr 2026, 11:59:00 am
    Author     : Admin
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Forwarding Data</title>
</head>
<body>
    <%-- 5. JSP Standard Action to forward the request to forwardInfo.jsp --%>
    <jsp:forward page="forwardInfo.jsp">
        <jsp:param name="uname" value="Wan Nural Jawahir Hj Wan Yussof" />
        <jsp:param name="email" value="wannurwy@umt.edu.my" />
        <jsp:param name="nationality" value="Malaysia" />
        <jsp:param name="background" value="Lecturer" />
    </jsp:forward>
</body>
</html>