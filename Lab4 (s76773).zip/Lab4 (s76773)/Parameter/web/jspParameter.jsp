<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>JSP Parameter</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f6f7f8; /* Light gray background matching the image */
            display: flex;
            flex-direction: column;
            align-items: center;
            padding-top: 60px;
            margin: 0;
        }
        .header-banner {
            border-left: 4px solid #673ab7; /* Purple left border */
            padding-left: 15px;
            margin-bottom: 20px;
            width: 100%;
            max-width: 550px;
        }
        .header-banner h2 {
            margin: 0;
            font-size: 1.1rem;
            color: #222;
        }
    </style>
</head>
<body>

<%
    // Define the variables
    String sCode = "CSE3023";
    String sSubject = "Web-based Application Development";
    String sCredit = "3(2+1)";
%>

    <div class="header-banner">
        <h2>Using jsp:include and jsp:param to display<br>information on JSP Page</h2>
    </div>

    <jsp:include page="subjectInfo.jsp">
        <jsp:param name="code" value="<%= sCode %>" />
        <jsp:param name="subject" value="<%= sSubject %>" />
        <jsp:param name="credit" value="<%= sCredit %>" />
    </jsp:include>

</body>
</html>