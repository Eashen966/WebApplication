<%@page contentType="text/html" pageEncoding="UTF-8"%>
<style>
    /* Styling specifically for the included card */
    .info-card {
        background-color: #ffffff;
        padding: 30px;
        border-radius: 6px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05); /* Subtle shadow */
        width: 100%;
        max-width: 505px; /* Slightly narrower than the title */
    }
    .info-card h3 {
        color: #8e24aa; /* Purple heading */
        margin-top: 0;
        margin-bottom: 25px;
        font-size: 1.25rem;
        font-weight: 600;
    }
    .info-card p {
        margin: 12px 0;
        color: #333;
        font-size: 0.95rem;
    }
</style>

<div class="info-card">
    <h3>Calling subjectInfo.jsp Page</h3>
    
    <p>Code: <%= request.getParameter("code") %></p>
    <p>Subject: <%= request.getParameter("subject") %></p>
    <p>Credit: <%= request.getParameter("credit") %></p>
</div>