<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Discount Result</title>
    <style>
        /* Base Styles from your CSS */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f7f6;
            margin: 0;
            padding: 20px;
        }
        .container {
            width: 100%;
            max-width: 900px;
            margin: 0 auto;
        }
        h1 {
            font-size: 1.5rem;
            color: #333;
            margin-bottom: 20px;
            border-left: 5px solid #6f42c1;
            padding-left: 10px;
        }
        .card {
            background: #ffffff;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            max-width: 500px; /* Matching the narrow card in the image */
        }
        .form-title {
            color: #6f42c1;
            font-size: 1.8rem;
            font-weight: 600;
            margin-top: 0;
            margin-bottom: 25px;
        }

        /* Output Row Styling */
        .output-group {
            margin-bottom: 20px;
        }
        .output-label {
            display: block;
            font-weight: bold;
            color: #555;
            margin-bottom: 5px;
        }
        .output-value {
            display: block;
            color: #333;
            margin-bottom: 15px;
        }

        /* Back Button */
        .btn-back {
            background-color: #6ef3d6;
            color: #333;
            border: 1px solid #adadad;
            padding: 5px 15px;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
            font-size: 0.9rem;
            display: inline-block;
        }
        .btn-back:hover {
            background-color: #d0d0d0;
        }
    </style>
</head>
<body>

<%
    // --- 1. JAVA LOGIC ---
    final double price = 10.0;
    String cust_no = request.getParameter("customerCode");
    String cust_type = request.getParameter("customerType");
    int quantity = 0;

    try {
        quantity = Integer.parseInt(request.getParameter("quantity"));
    } catch (Exception e) {
        quantity = 0;
    }

    double total = 0;
    String statusMessage = "";

    if ("1".equals(cust_type) && quantity > 100) {
        statusMessage = "You're entitled to 10% discount";
        total = quantity * price * 0.9;
    } else if ("2".equals(cust_type) && quantity > 100) {
        statusMessage = "You're entitled to 25% discount";
        total = quantity * price * 0.75;
    } else {
        statusMessage = "You're not entitled to any discount";
        total = quantity * price;
    }

    String custTypeDisplay = "1".equals(cust_type) ? "Normal Customer" : "Privilege Customer";
%>

    <div class="container">
        <h1>Customer Discount Result</h1>
        
        <div class="card">
            <h2 class="form-title">Transaction Summary</h2>
            
            <div class="output-group">
                <span class="output-label">Customer Code:</span>
                <span class="output-value"><%= (cust_no != null) ? cust_no : "" %></span>
            </div>

            <div class="output-group">
                <span class="output-label">Quantity:</span>
                <span class="output-value"><%= quantity %></span>
            </div>

            <div class="output-group">
                <span class="output-label">Customer Type:</span>
                <span class="output-value"><%= custTypeDisplay %></span>
            </div>

            <div class="output-group">
                <span class="output-label">Status:</span>
                <span class="output-value"><%= statusMessage %></span>
            </div>

            <div class="output-group">
                <span class="output-label">Total Amount:</span>
                <span class="output-value">RM <%= String.format("%.2f", total) %></span>
            </div>

            <a href="javascript:history.back()" class="btn-back">Back</a>
        </div>
    </div>

</body>
</html>