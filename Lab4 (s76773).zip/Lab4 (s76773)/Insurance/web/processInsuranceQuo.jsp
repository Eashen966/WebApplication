<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Insurance Quotation Result</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f7f6;
            margin: 0;
            padding: 40px;
        }
        .result-container {
            background: #ffffff;
            padding: 20px;
            max-width: 500px;
            margin: 0 auto; /* Added to center the container horizontally */
            border-top: 2px solid #333; 
        }
        .label {
            font-weight: bold;
            display: block;
            margin-top: 15px;
            color: #333;
        }
        .value {
            display: block;
            margin-top: 10px;
            margin-bottom: 20px;
            color: #333;
            font-size: 1.1rem;
        }
        .final-amount {
            font-weight: 800;
            font-size: 1.2rem;
        }
        .btn-back {
            background-color: #e0e0e0;
            color: #000;
            border: none;
            padding: 8px 30px;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
            text-decoration: none;
            display: inline-block;
            margin-top: 10px;
        }
    </style>
</head>
<body>

<%
    // --- logic from previous step ---
    String icNo = request.getParameter("icNo");
    String name = request.getParameter("userName");
    String coverage = request.getParameter("coverageType");
    String ncdStr = request.getParameter("ncdPercentage");
    
    double price = 0;
    double ncdRate = 0;

    try {
        price = Double.parseDouble(request.getParameter("price"));
        ncdRate = Double.parseDouble(ncdStr) / 100.0;
    } catch (Exception e) {
        price = 0;
        ncdRate = 0;
    }

    double rate = "Comprehensive".equalsIgnoreCase(coverage) ? 0.05 : 0.03;
    double baseInsurance = price * rate;
    double ncdDiscount = baseInsurance * ncdRate;
    double afterNCD = baseInsurance - ncdDiscount;
    double sst = afterNCD * 0.08;
    double finalAmount = afterNCD + sst;
%>

    <div class="result-container">
        
        <span class="label">Base Insurance:</span>
        <span class="value">RM <%= String.format("%.2f", baseInsurance) %></span>

        <span class="label">NCD Discount:</span>
        <span class="value">RM <%= String.format("%.2f", ncdDiscount) %></span>

        <span class="label">After NCD:</span>
        <span class="value">RM <%= String.format("%.2f", afterNCD) %></span>

        <span class="label">SST (8%):</span>
        <span class="value">RM <%= String.format("%.2f", sst) %></span>

        <span class="label">Final Insurance Amount:</span>
        <span class="value final-amount">RM <%= String.format("%.2f", finalAmount) %></span>

        <a href="insuranceQuotation.jsp" class="btn-back">Back</a>
        
    </div>

</body>
</html>