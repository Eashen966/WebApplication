<%-- 
    Document   : insuranceQuotation
    Created on : 21 Apr 2026, 14:13:33 pm
    Author     : Eashenraj
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Insurance Quotation</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f7f6;
            margin: 0;
            padding: 20px;
        }
        .container {
            width: 100%;
            max-width: 900px;
            margin: 0 auto;
        }
        h1 {
            font-size: 1.5rem;
            color: #333;
            margin-bottom: 20px;
            border-left: 5px solid #6f42c1;
            padding-left: 10px;
        }
        .card {
            background: #ffffff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            max-width: 600px;
            margin: 0 auto;
        }
        /* Fieldset for the "Insurance Calculation" border */
        fieldset {
            border: 1px solid #ddd;
            border-radius: 4px;
            padding: 20px;
        }
        legend {
            font-weight: bold;
            color: #555;
            padding: 0 10px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            font-weight: bold;
            margin-bottom: 8px;
            color: #555;
        }
        input[type="text"],
        input[type="number"],
        select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
            font-size: 0.95rem;
        }
        .button-group {
            margin-top: 10px;
            display: flex;
            gap: 10px;
        }
        .btn {
            padding: 8px 20px;
            border: 1px solid #adadad;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
            background-color: #e0e0e0;
            color: #333;
        }
        .btn:hover {
            background-color: #d0d0d0;
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>Insurance Quotation</h1>
        
        <div class="card">
            <form action="processInsuranceQuo.jsp" method="post">
                <fieldset>
                    <legend>Insurance Calculation</legend>

                    <div class="form-group">
                        <label for="icNo">IC No*</label>
                        <input type="text" id="icNo" name="icNo" placeholder="E.g. 821210-05-3478" required>
                    </div>

                    <div class="form-group">
                        <label for="userName">Name*</label>
                        <input type="text" id="userName" name="userName" placeholder="Enter name" required>
                    </div>

                    <div class="form-group">
                        <label for="price">Market Price*</label>
                        <input type="number" id="price" name="price" placeholder="Price" step="0.01" required>
                    </div>

                    <div class="form-group">
                        <label for="coverage">Coverage Type</label>
                        <select id="coverage" name="coverageType">
                            <option value="Third Party">Third Party</option>
                            <option value="Comprehensive">Comprehensive</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="ncd">No Claims Discount (NCD)</label>
                        <select id="ncd" name="ncdPercentage">
                            <option value="0">0%</option>
                            <option value="10">10%</option>
                            <option value="25">25%</option>
                            <option value="30">30%</option>
                            <option value="45">45%</option>
                            <option value="55">55%</option>
                        </select>
                    </div>

                    <div class="button-group">
                        <button type="submit" class="btn">Submit</button>
                        <button type="reset" class="btn">Cancel</button>
                    </div>
                </fieldset>
            </form>
        </div>
    </div>

</body>
</html>