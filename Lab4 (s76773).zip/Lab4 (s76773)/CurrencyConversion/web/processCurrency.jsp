<%-- 
    Document   : processCurrency
    Created on : 21 Apr 2026, 13:45:34 pm
    Author     : Eashenraj
--%>

<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Currency Conversion Result</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f7f6;
            margin: 0;
            padding: 20px;
        }
        .container {
            width: 100%;
            max-width: 900px;
            margin: 0 auto;
        }
        h1 {
            font-size: 1.5rem;
            color: #333;
            margin-bottom: 20px;
            border-left: 5px solid #6f42c1;
            padding-left: 10px;
        }
        .card {
            background: #ffffff;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            max-width: 500px;
        }
        .form-title {
            color: #6f42c1;
            font-size: 1.8rem;
            font-weight: 600;
            margin-top: 0;
            margin-bottom: 25px;
        }
        .output-group {
            margin-bottom: 20px;
        }
        .output-label {
            display: block;
            font-weight: bold;
            color: #555;
            margin-bottom: 5px;
        }
        .output-value {
            display: block;
            color: #333;
            margin-bottom: 15px;
            font-size: 1.1rem;
        }
        .btn-back {
            background-color: #e0e0e0;
            color: #333;
            border: 1px solid #adadad;
            padding: 8px 20px;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
            font-weight: bold;
            display: inline-block;
        }
    </style>
</head>
<body>

<%! 
    // --- 3. JSP DECLARATION TAG ---
    // Define constant exchange rates
    final double USD_RATE = 0.25;
    final double EURO_RATE = 0.21;
    final double JPY_RATE = 40.0;
    final double SGD_RATE = 0.32;

    // Reusable method to calculate conversion
    private double calculateRate(String currency, int amount) {
        double currencyChange = 0.0;
        if (currency != null) {
            if (currency.equals("1")) {
                currencyChange = amount * USD_RATE;
            } else if (currency.equals("2")) {
                currencyChange = amount * EURO_RATE;
            } else if (currency.equals("3")) {
                currencyChange = amount * JPY_RATE;
            } else if (currency.equals("4")) {
                currencyChange = amount * SGD_RATE;
            }
        }
        return currencyChange;
    }
%>

<%
    // --- 5. JSP SCRIPTLET ---
    String currencyType = request.getParameter("currencyType");
    String amountRaw = request.getParameter("amount");
    int amount = 0;
    double total = 0;

    try {
        if (amountRaw != null) {
            amount = Integer.parseInt(amountRaw);
            total = calculateRate(currencyType, amount);
        }
    } catch (Exception e) {
        amount = 0;
    }

    // Determine currency name for display
    String currencyName = "N/A";
    if ("1".equals(currencyType)) currencyName = "USD";
    else if ("2".equals(currencyType)) currencyName = "EURO";
    else if ("3".equals(currencyType)) currencyName = "JPY";
    else if ("4".equals(currencyType)) currencyName = "SGD";
%>

    <div class="container">
        <h1>Currency Conversion Result</h1>
        
        <div class="card">
            <h2 class="form-title">Transaction Summary</h2>
            
            <div class="output-group">
                <span class="output-label">Amount in Ringgit Malaysia (RM):</span>
                <span class="output-value">RM <%= amount %></span>
            </div>

            <div class="output-group">
                <span class="output-label">Converted to (<%= currencyName %>):</span>
                <span class="output-value">
                    <%-- --- 6. JSP EXPRESSION --- --%>
                    <%= (currencyName.equals("JPY") ? String.format("%.0f", total) : String.format("%.2f", total)) %> 
                    <%= currencyName %>
                </span>
            </div>

            <a href="currencyConversion.html" class="btn-back">Back</a>
        </div>
    </div>

</body>
</html>