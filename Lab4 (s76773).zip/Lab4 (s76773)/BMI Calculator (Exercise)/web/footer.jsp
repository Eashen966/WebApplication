<%-- 
    Document   : footer.jsp
    Author     : Eashenraj
--%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
        
        </div> 
        
        <div style="text-align: center; margin-top: 20px; padding: 15px; color: #666; font-size: 0.9rem;">
            &copy; 2026 Health Portal by Eashenraj. All Rights Reserved.
        </div>
    </body>
</html>