<%-- 
    Document   : processBMI.jsp
    Author     : Eashenraj
--%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>

<%
    String weightStr = request.getParameter("weight");
    String heightStr = request.getParameter("height");
    
    double weight = 0;
    double height = 0;
    double bmi = 0;
    String formattedBmi = "0.00";
    String category = "Unknown";
    String statusColor = "#333";

    if (weightStr != null && heightStr != null && !weightStr.isEmpty() && !heightStr.isEmpty()) {
        try {
            weight = Double.parseDouble(weightStr);
            height = Double.parseDouble(heightStr);
            
            if (weight > 0 && height > 0) {
                bmi = weight / (height * height);
                formattedBmi = String.format("%.2f", bmi); // Formatted cleanly in Java!
                
                if (bmi < 18.5) {
                    category = "Underweight";
                    statusColor = "#f39c12"; // Orange
                } else if (bmi >= 18.5 && bmi <= 24.9) {
                    category = "Normal Weight";
                    statusColor = "#27ae60"; // Green
                } else if (bmi >= 25 && bmi <= 29.9) {
                    category = "Overweight";
                    statusColor = "#e67e22"; // Dark Orange
                } else {
                    category = "Obese";
                    statusColor = "#c0392b"; // Red
                }
            } else {
                category = "Invalid Data (Zero or Negative)";
            }
        } catch (NumberFormatException e) {
            category = "Invalid Input";
        }
    }
%>

<jsp:forward page="resultBMI.jsp">
    <jsp:param name="finalBmi" value="<%= formattedBmi %>" />
    <jsp:param name="finalCategory" value="<%= category %>" />
    <jsp:param name="finalColor" value="<%= statusColor %>" />
</jsp:forward>