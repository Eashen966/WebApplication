<%-- 
    Document   : resultBMI.jsp
    Author     : Eashenraj
--%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@include file="header.jsp" %>

<h1>Your BMI Result</h1>

<div style="background-color: #fff; padding: 30px; border-radius: 8px; border: 1px solid #e0e0e0; text-align: center; margin-bottom: 20px;">
    
    <h2 style="margin: 0; font-size: 2.5rem; color: #007BFF;">
        <%= request.getParameter("finalBmi") %>
    </h2>
    
    <h3 style="margin-top: 10px; color: <%= request.getParameter("finalColor") %>;">
        Status: <%= request.getParameter("finalCategory") %>
    </h3>
    
</div>

<a href="bmiCalculator.jsp" style="display: inline-block; padding: 10px 20px; background: #e0e0e0; color: #333; text-decoration: none; border-radius: 4px; font-weight: bold;">
    Calculate Again
</a>

<%@include file="footer.jsp" %>