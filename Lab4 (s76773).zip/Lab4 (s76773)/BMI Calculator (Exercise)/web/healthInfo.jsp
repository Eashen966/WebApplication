<%-- 
    Document   : healthInfo
    Created on : 21 Apr 2026, 13:30:50?pm
    Author     : Eashenraj
--%>

<%@page import="java.util.ArrayList"%>
<%@include file="header.jsp" %>

<h1>BMI Categories</h1>
<table border="1" style="width:100%; border-collapse: collapse; text-align: left;">
    <tr style="background: #6f42c1; color: white;">
        <th style="padding: 10px;">Classification</th>
        <th style="padding: 10px;">BMI Range</th>
    </tr>
    <%
        ArrayList<String[]> categories = new ArrayList<>();
        categories.add(new String[]{"Underweight", "< 18.5"});
        categories.add(new String[]{"Normal", "18.5 - 25.0"});
        categories.add(new String[]{"Overweight", "> 25.0"});

        for (String[] row : categories) {
    %>
    <tr>
        <td style="padding: 10px;"><%= row[0]%></td>
        <td style="padding: 10px;"><%= row[1]%></td>
    </tr>
    <% }%>
</table>

<%@include file="footer.jsp" %>