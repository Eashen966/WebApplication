<%-- 
    Document   : bmiCalculator
    Created on : 21 Apr 2026, 13:28:50?pm
    Author     : Eashenraj
--%>

<%@include file="header.jsp" %>

<h1>BMI Calculator</h1>
<form action="processBMI.jsp" method="post">
    <div style="margin-bottom: 15px;">
        <label>Weight (kg):</label><br>
        <input type="number" name="weight" step="0.01" required style="width:100%; padding:8px;">
    </div>
    <div style="margin-bottom: 15px;">
        <label>Height (m):</label><br>
        <input type="number" name="height" step="0.01" required style="width:100%; padding:8px;">
    </div>
    <button type="submit" style="padding: 10px 20px; background: #6f42c1; color: white; border: none; border-radius: 4px; cursor: pointer;">
        Calculate BMI
    </button>
</form>

<%@include file="footer.jsp" %>